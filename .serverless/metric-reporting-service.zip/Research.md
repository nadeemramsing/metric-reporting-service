# Deployment to AWS Lambda
- @vendia/serverless-express

# Benchmark
- npx loadtest --rps 100 -k -n 1500 -c 50 https://xxxx.execute-api.us-east-1.amazonaws.com/prod/users (https://github.com/vendia/serverless-express)